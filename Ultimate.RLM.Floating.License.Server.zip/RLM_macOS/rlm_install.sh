#! /bin/bash
#
# RLM Service Installer
#
# Ultimate RLM floating license server Uninstaller
# Developed by Ahad Mohebbi

clear
echo "======== Installing the License Server on macOS ========"
echo "Starting the RLM license server"

#extract license files...
sudo tar -xf ./rlm.tar -C /Users/Shared/

#setup com.RLMLicenseServer.plist service for machine startup...
sudo cp ./com.RLMLicenseServer.plist /Library/LaunchDaemons/
sudo chown root /Library/LaunchDaemons/com.RLMLicenseServer.plist
sudo launchctl load -w /Library/LaunchDaemons/com.RLMLicenseServer.plist

#set execute permission for license utilities...
sudo chmod -R 755 /Users/Shared/rlm

#setup licens environment in stratup bash files...
if [ -f ~/.zshrc ]; then
	echo "source /Users/Shared/rlm/rlmenvset.sh" >> ~/.zshrc
fi

if [ -f ~/.bashrc ]; then
	echo "source /Users/Shared/rlm/rlmenvset.sh" >> ~/.bashrc
fi

if [ -f ~/.bash_profile ]; then
	echo "source /Users/Shared/rlm/rlmenvset.sh" >> ~/.bash_profile
fi

#setup foundry license files...
FOUNDRY_LIC_PATH="/Library/Application\ Support/TheFoundry/RLM/"
if [ -e "$FOUNDRY_LIC_PATH" ];
then
	cd /Users/Shared/rlm	
	sudo cp ./foundry.lic /Library/Application\ Support/TheFoundry/RLM/
	sudo cp ./foundry.set /Library/Application\ Support/TheFoundry/RLM/
	sudo chmod -R 777 /Library/Application\ Support/TheFoundry/RLM/
else
	cd /Users/Shared/rlm 
	sudo mkdir -p /Library/Application\ Support/TheFoundry/RLM/
	sudo mkdir -p /Library/Application\ Support/TheFoundry/RLM/log
	sudo cp ./foundry.lic /Library/Application\ Support/TheFoundry/RLM/
	sudo cp ./foundry.set /Library/Application\ Support/TheFoundry/RLM/
	sudo chmod -R 777 /Library/Application\ Support/TheFoundry/RLM/
fi

#setup genarts license files...
GENARTS_LIC_PATH="/Library/Application\ Support/GenArts/rlm/"
if [ -e "$GENARTS_LIC_PATH" ];
then
	sudo rm /Library/Application\ Support/GenArts/rlm/*
	cd /Users/Shared/rlm 
	sudo cp ./genarts.lic /Library/Application\ Support/GenArts/rlm/
	sudo cp ./genarts.set /Library/Application\ Support/GenArts/rlm/
	sudo cp ./genarts.lic /Library/Application\ Support/GenArts/rlm/
	sudo chmod -R 777 /Library/Application\ Support/GenArts/rlm/
else
	cd /Users/Shared/rlm
	sudo mkdir -p /Library/Application\ Support/GenArts/rlm
	sudo cp ./genarts.lic /Library/Application\ Support/GenArts/rlm/
	sudo cp ./genarts.set /Library/Application\ Support/GenArts/rlm/
	sudo cp ./genarts.lic /Library/Application\ Support/GenArts/rlm/
	sudo chmod -R 777 /Library/Application\ Support/GenArts/rlm/
fi

#setup peregrineLabs license files...
PEREGRINELABS_LIC_PATH="/Library/Application\ Support/PeregrineLabs/rlm/"
if [ -e "$PEREGRINELABS_LIC_PATH" ];
then
	cd /Users/Shared/rlm 
	sudo cp ./peregrinel.lic /Library/Application\ Support/PeregrineLabs/rlm/
	sudo cp ./peregrinel.set /Library/Application\ Support/PeregrineLabs/rlm/
	sudo chmod -R 777 /Library/Application\ Support/PeregrineLabs/rlm/
else
	cd /Users/Shared/rlm 
	sudo mkdir -p /Library/Application\ Support/PeregrineLabs/rlm/
	sudo cp ./peregrinel.lic /Library/Application\ Support/PeregrineLabs/rlm/
	sudo cp ./peregrinel.set /Library/Application\ Support/PeregrineLabs/rlm/
	sudo chmod -R 777 /Library/Application\ Support/PeregrineLabs/rlm/
fi

#setup maxwell license files...
MAXWELL_LIC_PATH="/Users/Shared/NextLimit/rlm_nl/licenses"
if [ -e "$PEREGRINELABS_LIC_PATH" ];
then
	cd /Users/Shared/rlm 
	sudo cp ./nextlimit.set /Users/Shared/NextLimit/rlm_nl/licenses
	sudo cp ./nextlimit.lic /Users/Shared/NextLimit/rlm_nl/licenses
	sudo chmod -R 777 /Users/Shared/NextLimit/rlm_nl/licenses
else
	cd /Users/Shared/rlm 
	sudo mkdir -p /Users/Shared/NextLimit/rlm_nl/licenses
	sudo cp ./nextlimit.set /Users/Shared/NextLimit/rlm_nl/licenses
	sudo cp ./nextlimit.lic /Users/Shared/NextLimit/rlm_nl/licenses
	sudo chmod -R 777 /Users/Shared/NextLimit/rlm_nl/licenses
fi

echo "Starting the RLM License Manager..."
sudo /Users/Shared/rlm/rlm -dlog +"rlm_lic.dlog" &
echo "The RLM License Server Successfully Installed."
cd $HOME
