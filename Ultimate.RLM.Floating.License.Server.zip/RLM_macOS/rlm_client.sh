#! /bin/bash
#
# RLM Service Installer
#
# Ultimate RLM floating license server Uninstaller
# Developed by Ahad Mohebbi


# check the "--help" argument
if [[ $1 = '--help' ]]; then

	echo "RLM License Manager for Client[s]..."
	echo "developed by Ahad Mohebbi"
	echo ""
	echo "Usage: rlm_client.sh [ARGUMENT] [OPTION]"
	echo "Add and Remove License environment for client[s]"
	echo ""
	echo "[ARGUMENTS]"
	echo "--add          add license environment to the client[s]."
	echo "--remove       remove license environment to the client[s]."
	echo "--help         display how to use this script."
	echo ""
	echo "[OPTION]"
	echo "YOUR_SERVER_HOST_NAME   [OR]   YOUR_SERVER_IP" 
	echo ""
	echo "Examples:"
	echo "add license environment..."
	echo "	sudo rlm_client.sh --add VFX_SERVER"
	echo "	sudo rlm_client.sh -add 192.168.1.50"
	echo ""
	echo "remove license environment..."
	echo "	sudo rlm_client.sh --remove"
	echo ""
	exit 0
fi

# check arguments for Add and Hostname|HostID argument's
if [[ ! $1 ]]; then
	echo ""
	echo "Missing argument's ..."
	echo "**********************"
	echo ""
	echo "RLM License Manager for Client[s]..."
	echo "developed by Ahad Mohebbi"
	echo ""
	echo "Usage:  rlm_client.sh [ARGUMENT] [OPTION]"
	echo "Add and Remove License environment for client[s]"
	echo ""
	echo "[ARGUMENTS]"
	echo "--add          add license environment to the client[s]."
	echo "--remove       remove license environment to the client[s]."
	echo "--help         display how to use this script."
	echo ""
	echo "[OPTION]"
	echo "YOUR_SERVER_HOST_NAME  .......... the HOST name of your server that RLM License Manager Installed on it."
	echo "YOUR_SERVER_IP" 
	echo ""
	echo "Examples:"
	echo "add license environment..."
	echo "	sudo rlm_client.sh --add VFX_SERVER"
	echo "	sudo rlm_client.sh -add 192.168.1.50"
	echo ""
	echo "remove license environment..."
	echo "	sudo rlm_client.sh --remove"
	echo ""
	exit 1
fi

#Check the "--add" and "HOST_name | HOST_ID" argument's
if [[ $1 = '--add' ]] && [[ $2 ]]; then
		#Check the ".bash_profile" Profile to add lic loader
	if [[ -e ~/.bash_profile ]] && [[ -e /Users/Shared/.rlmrc ]]; then
			echo "RLM License Manager has been installed on your client[s]."
			exit 1
		else
			sudo touch /Users/Shared/.rlmrc
			sudo chmod 777 /Users/Shared/.rlmrc
			echo "export fabricinc_LICENSE=5053@$2" >> /Users/Shared/.rlmrc
			echo "export foundry_LICENSE=5053@$2" >> /Users/Shared/.rlmrc
			echo "export genarts_LICENSE=5053@$2" >> /Users/Shared/.rlmrc
			echo "export golaem_LICENSE=5053@$2" >> /Users/Shared/.rlmrc
			echo "export innobright_LICENSE=5053@$2" /Users/Shared/.rlmrc
			echo "export mootzoid_LICENSE=5053@$2" >> /Users/Shared/.rlmrc
			echo "export nextlimit_LICENSE=5053@$2" >> /Users/Shared/.rlmrc
			echo "export peregrinel_LICENSE=5053@$2" >> /Users/Shared/.rlmrc
			echo "export redshift_LICENSE=5053@$2" >> /Users/Shared/.rlmrc
			echo "export solidangle_LICENSE=5053@$2" >> /Users/Shared/.rlmrc
			echo "export SFX_LICENSE_SERVER=5053@$2" >> /Users/Shared/.rlmrc
			echo "export PATH=$PATH:fabricinc_LICENSE:foundry_LICENSE:genarts_LICENSE:golaem_LICENSE:innobright_LICENSE:mootzoid_LICENSE:nextlimit_LICENSE:peregrinel_LICENSE:redshift_LICENSE:solidangle_LICENSE:SFX_LICENSE_SERVER" >> ~/.rlmrc
			echo "source /Users/Shared/.rlmrc" >> ~/.bash_profile
			
			echo "successfull Install fabricinc_LICENSE=5053@$2 "
			echo "successfull Install foundry_LICENSE=5053@$2"
			echo "successfull Install genarts_LICENSE=5053@$2"
			echo "successfull Install golaem_LICENSE=5053@$2"
			echo "successfull Install innobright_LICENSE=5053@$2"
			echo "successfull Install mootzoid_LICENSE=5053@$2"
			echo "successfull Install nextlimit_LICENSE=5053@$2"
			echo "successfull Install peregrinel_LICENSE=5053@$2"
			echo "successfull Install redshift_LICENSE=5053@$2"
			echo "successfull Install solidangle_LICENSE=5053@$2"
			echo "successfull Install SFX_LICENSE_SERVER=5053@$2"
			echo "======================================================="
			echo "License environment successfully add to your client[s]."	
			
	fi
fi


#Check the "--remove" argument...
if [[ $1 == '--remove' ]]; then

	#Check the ".bash_profile" Profile for remove lic loader
	if [[ -e ~/.bash_profile ]] && [[ -e /Users/Shared/.rlmrc ]]; then
		sudo rm /Users/Shared/.rlmrc
		sudo sed -i.bak '/rlmrc/d' ~/.bash_profile
		echo "Successfull Remove fabricinc_LICENSE"
		echo "Successfull Remove foundry_LICENSE"
		echo "Successfull Remove genarts_LICENSE"
		echo "Successfull Remove golaem_LICENSE"
		echo "Successfull Remove innobright_LICENSE"
		echo "Successfull Remove mootzoid_LICENSE="
		echo "Successfull Remove nextlimit_LICENSE"
		echo "Successfull Remove peregrinel_LICENSE"
		echo "Successfull Remove redshift_LICENSE"
		echo "Successfull Remove solidangle_LICENSE"
		echo "Successfull Remove SFX_LICENSE_SERVER"
		echo "==========================================================="
		echo "License environment successfully removed on your client[s]."
	else
		echo "The RLM License Manager doesn't install on this client."
		exit 1
	fi	
fi