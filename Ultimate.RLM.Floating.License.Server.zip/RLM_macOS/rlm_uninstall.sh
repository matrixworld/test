#! /bin/bash
#
# RLM Service Installer
#
# Ultimate RLM floating license server Uninstaller
# Developed by Ahad Mohebbi
clear
echo "======== Uninstalling the License Server in macOS ========"
echo "Stop the RLM license server"

#stop RLM license manager and delete it...
if [ -f /Library/LaunchDaemons/com.RLMLicenseServer.plist ]; then
	sudo launchctl unload /Library/LaunchDaemons/com.RLMLicenseServer.plist
	sudo rm -f /Library/LaunchDaemons/com.RLMLicenseServer.plist
fi

#remove licens files
if [ -d /Users/Shared/rlm ]; then
	sudo rm -rf /Users/Shared/rlm
fi

#remove license environment form startup bash scripts...
if [ -f ~/.zshrc ]; then
	sudo sed -i.bak '/rlmenvset/d' ~/.zshrc
fi

if [ -f ~/.bashrc ]; then
	sudo sed -i.bak '/rlmenvset/d' ~/.bashrc
fi

if [ -f ~/.bash_profile ]; then
	sudo sed -i.bak '/rlmenvset/d' ~/.bash_profile
fi

#backup foundry License
if [ -d "/Library/Application Support/TheFoundry/RLM/" ] && [ -d "/Library/Application Support/TheFoundry/RLM.bak/" ];
then
	sudo rm -rf /Library/Application\ Support/TheFoundry/RLM
elif [ -d "/Library/Application Support/TheFoundry/RLM/" ]; 
then
	sudo mv /Library/Application\ Support/TheFoundry/RLM{,.bak}
fi


#backup genarts License
if [ -d "/Library/Application Support/GenArts/rlm" ] && [ -d "/Library/Application Support/GenArts/rlm.bak" ];
then
	sudo rm -rf /Library/Application\ Support/GenArts/rlm
elif [ -d "/Library/Application Support/GenArts/rlm" ]; 
then
	sudo mv /Library/Application\ Support/GenArts/rlm{,.bak}
fi


#PeregrineLabs Lic
if [ -d "/Library/Application Support/PeregrineLabs/rlm" ] && [ -d "/Library/Application Support/PeregrineLabs/rlm.bak" ];
then
	sudo rm -rf /Library/Application\ Support/PeregrineLabs/rlm
elif [ -d "/Library/Application Support/PeregrineLabs/rlm" ]; 
then
	sudo mv /Library/Application\ Support/PeregrineLabs/rlm{,.bak}
fi


#Maxwell License File
if [ -d "/Users/Shared/NextLimit/rlm_nl/licenses" ] && [ -d "/Users/Shared/NextLimit/rlm_nl/licenses.bak" ];
then
	sudo rm -rf /Users/Shared/NextLimit/rlm_nl/licenses
elif [ -d "/Users/Shared/NextLimit/rlm_nl/licenses" ]; 
then
	sudo mv /Users/Shared/NextLimit/rlm_nl/licenses{,.bak}
fi

echo "The RLM License Server successfully removed."
cd $HOME