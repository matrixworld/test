#! /bin/bash
#
# RLM Service Installer
#
# Ultimate RLM floating license server Uninstaller
# Developed by Ahad Mohebbi

clear
echo "======== Installing the License Server on Linux ========"
echo "Starting the RLM license server"

#extract license files...
sudo tar -xf ./rlm.tar -C /opt/

#setup rlmd service for machine startup...
sudo cp ./rlmd /etc/rc.d/init.d/
sudo cp ./rlmd /etc/init.d/
sudo chown root /etc/rc.d/init.d/rlmd
sudo chown root /etc/init.d/rlmd

#setting the execute permission...
sudo chmod +x /opt/rlm/rlm
sudo chmod +x /opt/rlm/rlmutil
sudo chmod +x /opt/rlm/rlmenvset.sh
sudo chmod +wrx /etc/rc.d/init.d/rlmd
sudo chmod +wrx /etc/init.d/rlmd

#start rlm service
sudo service rlmd start 

#setup licens environment in stratup bash files...
if [ -f ~/.bashrc ]; then
	echo "source /opt/rlm/rlmenvset.sh" >> ~/.bashrc
fi

if [ -f ~/.bash_profile ]; then
	echo "source /opt/rlm/rlmenvset.sh" >> ~/.bash_profile
fi


#setup foundry license files...
FOUNDRY_LIC_PATH="/usr/local/foundry/RLM"
if [ -e $FOUNDRY_LIC_PATH ];
then
	cd /opt/rlm	
	sudo cp ./foundry.lic /usr/local/foundry/RLM
	sudo cp ./foundry.set /usr/local/foundry/RLM
	sudo chmod -R 777 /usr/local/foundry
else
	cd /opt/rlm	
	sudo mkdir -p /usr/local/foundry/RLM
	sudo mkdir -p /usr/local/foundry/RLM/log
	sudo cp ./foundry.lic /usr/local/foundry/RLM
	sudo cp ./foundry.set /usr/local/foundry/RLM
	sudo chmod -R 777 /usr/local/foundry
fi

#setup genarts license files...
GENARTS_LIC_PATH="/usr/genarts/rlm/"
if [ -e $GENARTS_LIC_PATH ];
then
	cd /opt/rlm	
	sudo rm /usr/genarts/rlm/*
	sudo cp genarts.lic /usr/genarts/rlm
	sudo cp genarts.set /usr/genarts/rlm
	sudo chmod -R 777 /usr/genarts/rlm/
else
	cd /opt/rlm	
	sudo mkdir -p /usr/genarts/rlm/
	sudo cp genarts.lic /usr/genarts/rlm
	sudo cp genarts.set /usr/genarts/rlm
	sudo chmod -R 777 /usr/genarts/rlm/
fi

#setup peregrineLabs license files...
PEREGRINELABS_LIC_PATH="/var/PeregrineLabs/rlm/"
if [ -e $PEREGRINELABS_LIC_PATH ];
then
	cd /opt/rlm
	sudo cp peregrinel.set /var/PeregrineLabs/rlm/
	sudo cp peregrinel.lic /var/PeregrineLabs/rlm/
	sudo chmod -R 777 /var/PeregrineLabs/rlm/
else
	sudo mkdir -p /var/PeregrineLabs/rlm/
	cd /opt/rlm
	sudo cp peregrinel.set /var/PeregrineLabs/rlm/
	sudo cp peregrinel.lic /var/PeregrineLabs/rlm/
	sudo chmod -R 777 /var/PeregrineLabs/rlm/
fi

#setup maxwell license files...
MAXWELL_LIC_PATH="$HOME/Maxwell"
if [ -e $MAXWELL_LIC_PATH ];
then
	cd /opt/rlm
	sudo cp nextlimit.set $HOME/Maxwell
	sudo cp nextlimit.lic $HOME/Maxwell
	sudo chmod -R 777 $HOME/Maxwell
else
	sudo mkdir -p $HOME/Maxwell
	cd /opt/rlm
	sudo cp nextlimit.set $HOME/Maxwell
	sudo cp nextlimit.lic $HOME/Maxwell
	sudo chmod -R 777 $HOME/Maxwell
fi

echo "Starting the RLM License Manager..."
sudo /opt/rlm/rlm -dlog +"rlm_lic.dlog" &
echo "The RLM License Server Successfully Installed."
cd $HOME